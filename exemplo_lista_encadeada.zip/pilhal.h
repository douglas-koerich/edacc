/*
 * pilhal.h
 *
 *  Created on: Mar 17, 2010
 *      Author: dkoerich
 */

#ifndef PILHAL_H_
#define PILHAL_H_

#include "lista.h"

/* Tipo usado para definir externamente uma pilha na forma encadeada */
typedef No PilhaL;

/* Funcoes (interface) do TAD: pilha na forma encadeada */
int push(PilhaL** topo, tipo novo);
int pop(PilhaL** topo, tipo* valor);
int underflow(PilhaL* topo);

#endif /* PILHAL_H_ */
