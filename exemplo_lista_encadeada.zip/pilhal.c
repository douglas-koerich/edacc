/*
 * pilhal.c
 *
 *  Created on: Mar 17, 2010
 *      Author: dkoerich
 */

#include <stdlib.h>
#include "pilhal.h"

int push(PilhaL** topo, tipo novo) {
    return insInicio(topo, novo);
}

int pop(PilhaL** topo, tipo* valor) {
    return remInicio(topo, valor);
}

int underflow(PilhaL* topo) {
    return topo == NULL;
}
