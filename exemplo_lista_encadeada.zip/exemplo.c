#include <stdio.h>
#include "lista.h"
#include "pilhal.h"

void inverteLista(Lista* cabeca) {
    // Vou usar uma pilha (encadeada!) como estrutura auxiliar para inversao
    // Pilha eh uma LIFO!
    PilhaL* minhaPilha = NULL;  // "iniciaPilha"

    // Declara um ponteiro para ir apontando de noh em noh da lista encadeada
    No* p = cabeca;

    // Enquanto nao chega ao fim da lista...
    while (p != NULL) {
        push(&minhaPilha, p->elemento);
        p = p->proximo;
    }

    // Neste ponto, a pilha tem todos os valores que estao na lista, em sua
    // ordem original
    // Agora, recomeca o percurso da lista a partir do inicio, copiando o
    // valor que esta no topo da pilha
    p = cabeca; // Reinicia da cabeca
    while (!underflow(minhaPilha)) {
        pop(&minhaPilha, &p->elemento);
        p = p->proximo;
    }
}

int main(int argc, char* argv[]) {
    int i, fibonacci[] = { 0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, -1 };

    // Declaracao e consequente inicializacao de uma lista encadeada de elementos
    // do tipo T
    Lista* minhaLista = NULL; // a cabeca da lista esta vazia

    // Insere a sequencia de elementos no inicio da lista
    for (i=0; fibonacci[i] >= 0; ++i) {
        tipo elemento = fibonacci[i];
        if (insInicio(&minhaLista, elemento) == 0) {
            printf("Houve erro na insercao do elemento %d.\n", elemento);
            break;
        }
    }
    // Inverte a lista encadeada...
    inverteLista(minhaLista);

    // Liberar a memoria alocada pelos nos da lista
    while (minhaLista != NULL) {
        tipo x;
        remInicio(&minhaLista, &x);
    }
    return 0;
}