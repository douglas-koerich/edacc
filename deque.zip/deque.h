#ifndef DEQUE_H
#define DEQUE_H

#include <stdbool.h>

// Definicao das extremidades do deque
typedef enum Lado { INICIO, FIM } Lado;

// Definicao do TAD: deque de inteiros
typedef struct IDeque IDeque;

// Interface do TAD:
IDeque* cria(size_t max);
void destroi(IDeque* deque);
bool underflow(const IDeque* deque);
bool overflow(const IDeque* deque);
void enqueue(IDeque* deque, int numero, Lado lado);
int dequeue(IDeque* deque, Lado lado);
void print(const IDeque* deque);

#endif
