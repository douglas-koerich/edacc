#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "pilha.h"

struct Pilha {
    float* vetor;
    int topo;
};

#define MAX_ITENS   1000

Pilha* cria(void) {
    Pilha* p = malloc(sizeof(Pilha));
    p->vetor = malloc(sizeof(float) * MAX_ITENS);
    p->topo = -1;
    return p;
}

void destroi(Pilha* p) {
    free(p->vetor);
    free(p);
}

bool underflow(const Pilha* p) {
    return p->topo == -1;
}

bool overflow(const Pilha* p) {
    return p->topo == MAX_ITENS-1;
}

bool push(Pilha* p, float i) {
    if (overflow(p)) {
        return false;
    }
    ++p->topo;
    p->vetor[p->topo] = i;
    return true;
}

float pop(Pilha* p) {
    if (underflow(p)) {
        return -1.0;
    }
    float i = p->vetor[p->topo];
    --p->topo;
    return i;
}

void imprime(const Pilha* p) {
    if (underflow(p)) {
        printf("(VAZIA)");
        return;
    }
    int i;
    printf("(BASE) ");
    for (i=0; i<=p->topo; ++i) {
        printf("%.3f ", p->vetor[i]);
    }
    printf("(TOPO)"); 
}

