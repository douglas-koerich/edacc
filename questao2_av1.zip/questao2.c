#include <stdlib.h>
#include <stdio.h>
#include "pilha.h"

Pilha* agregada(Pilha*, Pilha*);

int main(int argc, char* argv[]) {
    float v1[] = { 1.0, 2.0, 3.0, 5.0, -1.0 };
    float v2[] = { 0.0, 4.0, 3.0, 10.0, 7.0, -1.0 };

    Pilha* P1 = cria();
    Pilha* P2 = cria();

    int i = 0;
    while (v1[i] >= 0.0) {
        push(P1, v1[i]);
        ++i;
    }
    i = 0;
    while (v2[i] >= 0.0) {
        push(P2, v2[i]);
        ++i;
    }

    printf("P1: "); imprime(P1); putchar('\n');
    printf("P2: "); imprime(P2); putchar('\n');

    Pilha* P3 = agregada(P1, P2);
    imprime(P3);
    putchar('\n');

    destroi(P1);
    destroi(P2);
    destroi(P3);

    return EXIT_SUCCESS;
}

Pilha* agregada(Pilha* P1, Pilha* P2) {
    // Eh a funcao 'agregada()' quem cria a pilha P3
    Pilha* P3 = cria();

    // Pilha auxiliar que permitira sair de P1 (ou P2) para P3
    Pilha* aux = cria();

    // Esvazia a pilha P1 para por em P3; precisa passar pela auxiliar
    // pra nao ficar invertida em P3 (e poder voltar pra P1)
    while (!underflow(P1)) {
        float f = pop(P1);
        push(aux, f);

        // Numa linha soh: push(aux, pop(P1));
    }
    // Restaura P1 e jah acumula em P3
    while (!underflow(aux)) {
        float f = pop(aux);
        push(P1, f);    // restaura para P1
        push(P3, f);    // copia para P3
    }

    // Processo SEMELHANTE se fara em P2, com a diferenca da volta da auxiliar
    while (!underflow(P2)) {
        float f = pop(P2);
        push(aux, f);
    }
    while (!underflow(aux)) {
        bool encontrei = false;
        float f = pop(aux);
        push(P2, f);    // restaura para P2

        // Aqui estah o ponto de diferenca: SOH vai colocar tambem em P3 se
        // NAO achar esse valor em P1 - pra isso vai precisar esvaziar P1
        // a procura desse valor nessa pilha
        Pilha* aux2 = cria();
        while (!underflow(P1)) {
            float f1 = pop(P1);
            if (f1 == f) {
                // ENCONTREI o mesmo valor em P1!!
                encontrei = true;
            }
            push(aux2, f1);
        }
        // Restaura a pilha P1 depois de inspecionar todo o seu conteudo
        while (!underflow(aux2)) {
            push(P1, pop(aux2));
        }
        destroi(aux2);

        // Soh vai para a pilha P3 se durante a inspecao da pilha P1 (usando
        // a pilha aux2 como apoio) o numero recuperado para P2 nao foi encontrado
        if (encontrei == false) {
            push(P3, f);
        }
    }
    // Destroi a pilha auxiliar antes de devolver P3
    destroi(aux);

    return P3;
}

