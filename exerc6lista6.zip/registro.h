#ifndef REGISTRO_H
#define REGISTRO_H

struct Registro {
    int chave;
    char outro;
    /*... outros campos ...*/
};
typedef struct Registro R;

#endif

