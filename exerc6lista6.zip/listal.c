#include <stdio.h>
#include "listal.h"

struct Noh {
    R elemento;
    struct Noh* proximo;
};

struct Lista {
    struct Noh* cabeca;
};

struct Lista* lcria(void) {
    struct Lista* l = (struct Lista*) malloc(sizeof(struct Lista));
    l->cabeca = NULL;
    return l;
}

void ldestroi(struct Lista* l) {
    while (l->cabeca != NULL) {
        struct Noh* p = l->cabeca;
        l->cabeca = p->proximo;
        free(p);
    }
    free(l);
}

bool lunderflow(const struct Lista* l) {
    return l->cabeca == NULL;
}

R* lbusca(const struct Lista* l, int chave) {
    if (lunderflow(l)) {
        return NULL;
    }
    struct Noh* p = l->cabeca;
    while (p != NULL) {
        if (p->elemento.chave == chave) {
            return &p->elemento;
        }
        p = p->proximo;
    }
    return NULL;
}

bool linserir(struct Lista* l, const R* registro) {
    struct Noh* p = (struct Noh*) malloc(sizeof(struct Noh));
    if (p == NULL) {
        return false;
    }
    p->elemento = *registro;
    p->proximo = NULL;
    if (l->cabeca == NULL) {
        l->cabeca = p;
    }
    else {
        struct Noh* q = l->cabeca;
        while (q->proximo != NULL) {
            q = q->proximo;
        }
        q->proximo = p;
    }
    return true;
}

void limprime(const struct Lista* l) {
    printf("->");
    struct Noh* p = l->cabeca;
    while (p != NULL) {
        printf("%u->", p->elemento.chave);
        p = p->proximo;
    }
    puts("||");
}
