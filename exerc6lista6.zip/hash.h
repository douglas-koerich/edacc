#ifndef HASH_H
#define HASH_H

#include "registro.h"

// Definicao da tabela de hashing
struct Hashing;

// Interface (API) para uso do algoritmo de insercao e busca por hashing
struct Hashing* cria(size_t M); // M = tamanho desejado do vetor/banco de dados
void destroi(struct Hashing* h);
void insere(struct Hashing* h, const R* registro);
R* busca(const struct Hashing* h, int chave);
void imprime(const struct Hashing* h);
// ... outras funcoes da interface podem ser acrescentadas, para remover, etc.

#endif
