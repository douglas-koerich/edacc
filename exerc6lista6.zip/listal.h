#ifndef LISTAL_H
#define LISTAL_H

#include <stdbool.h>
#include <stdlib.h>
#include "registro.h"

// TAD: Lista linear de elementos
struct Lista;

// Interface do TAD: lista
struct Lista* lcria(void);
void ldestroi(struct Lista* l);
bool lunderflow(const struct Lista* l);
R* lbusca(const struct Lista* l, int chave);
bool linserir(struct Lista* l, const R* registro);
void limprime(const struct Lista* l);

// ... a medida que outras funcoes sao acrescentadas ao hashing (p.ex. remover),
// eh provavel que removerValor() seria necessario aqui

#endif
