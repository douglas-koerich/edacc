#include <stdio.h>
#include "registro.h"
#include "hash.h"

int main() {
    printf("Digite a capacidade esperada para o banco de dados: ");
    int M;
    scanf("%d", &M);

    // Cria o banco de dados baseado em hashing
    struct Hashing* h = cria(M);

    // Pede algumas chaves e acrescenta ao banco de dados, imprimindo sua
    // disposicao na memoria
    R reg;
    do {
        printf("Digite uma nova chave (0 para encerrar): ");
        scanf("%d", &reg.chave);
        if (reg.chave > 0) {
            insere(h, &reg);
            imprime(h);
        }
    } while (reg.chave > 0);

    // Exercita a busca no banco de dados
    int chave;
    do {
        printf("Digite uma chave para busca (0 para encerrar): ");
        scanf("%d", &chave);
        if (chave > 0) {
            if (busca(h, chave) != NULL) {
                puts("Chave encontrada!");
            }
            else {
                puts("Chave NAO existe no banco de dados!");
            }
        }
    } while (chave > 0);

    // Finalmente, destroi o banco de dados
    destroi(h);

    return 0;
}
