#include <stdlib.h>
#include <stdio.h>
#include "listal.h"
#include "registro.h"

// Definicao interna da estrutura
struct Hashing {
    struct Lista** vetor;   // vetor de ponteiros alocado dinamicamente
    size_t tamanho;
    size_t divisor;
};

static size_t maior_primo_menor_que_tamanho(size_t M) {
    size_t P = M;
    while (P > 1) {
        int n = 1;
        bool primo = true;
        while (++n < P) {
            if (P % n == 0) {
                primo = false;
                break;
            }
        }
        if (primo == true) {
            break;
        }
        --P;
    }
    return P;
}

struct Hashing* cria(size_t M) {
    struct Hashing* h = (struct Hashing*) malloc(sizeof(struct Hashing));
    h->tamanho = M;
    h->divisor = maior_primo_menor_que_tamanho(h->tamanho);
    h->vetor = (struct Lista**) malloc(h->tamanho * sizeof(struct Lista*));
    int i;
    for (i=0; i<h->tamanho; ++i) {
        h->vetor[i] = lcria();
    }
    return h;
}

void destroi(struct Hashing* h) {
    int i;
    for (i=0; i<h->tamanho; ++i) {
        ldestroi(h->vetor[i]);
    }
    free(h->vetor);
    free(h);
}

// A funcao de hashing, usada para determinar em qual indice do vetor de listas
// de chaves sinonimas deve ser inserida/buscada uma (nova) chave
static unsigned hashing(const struct Hashing* h, int chave) {
    return chave % h->divisor;
}

void insere(struct Hashing* h, const R* registro) {
    int posicao = hashing(h, registro->chave);
    linserir(h->vetor[posicao], registro);
}

R* busca(const struct Hashing* h, int chave) {
    int posicao = hashing(h, chave);
    return lbusca(h->vetor[posicao], chave);
}

void imprime(const struct Hashing* h) {
    int i;
    for (i=0; i<h->tamanho; ++i) {
        printf("[%d]", i);
        limprime(h->vetor[i]);
    }
}
