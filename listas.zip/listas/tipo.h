#ifndef TIPO_H
#define TIPO_H

typedef unsigned tipo;

#endif
