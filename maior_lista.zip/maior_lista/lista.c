#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "lista.h"

// Declaracao da variavel global de registro invalido
const Reg REG_INVALIDO = { -1, 0 };

// Definicao interna do no de lista, nao visivel para usuario da lista
struct Noh {
    Reg elemento;
    struct Noh* proximo;
};

// Definicao pratica da lista encadeada
struct Lista {
    struct Noh* cabeca;
};

struct Lista* cria(void) {
    struct Lista* l = (struct Lista*) malloc(sizeof(struct Lista));
    l->cabeca = NULL;
    return l;
}

// Uma funcao static soh eh visivel por outras funcoes dentro do mesmo
// arquivo-fonte
static Reg removeInicio(struct Lista* l) {
    if (underflow(l)) {
        return REG_INVALIDO;
    }
    struct Noh* x = l->cabeca;
    l->cabeca = x->proximo;
    Reg r = x->elemento;
    free(x);
    return r;
}

void destroi(struct Lista* l) {
    while (!underflow(l)) {
        removeInicio(l);
    }
    free(l);
}

bool underflow(const struct Lista* l) {
    return l->cabeca == NULL;
}

void insere(struct Lista* l, const Reg* novo) {
    struct Noh* n = (struct Noh*) malloc(sizeof(struct Noh));
    n->elemento = *novo;
    n->proximo = NULL;
    if (underflow(l)) {
        l->cabeca = n;
        return;
    }
    struct Noh* p = l->cabeca;
    while (p->proximo != NULL) {
        p = p->proximo;
    }
    p->proximo = n;
}

void imprime(struct Lista* l) {
    if (underflow(l)) {
        printf("(vazia)");
        return;
    }
    printf("(Cabeca) ");
    struct Noh* p = l->cabeca;
    while (p != NULL) {
        printf("{%d,%d}@%p--", p->elemento.chave, p->elemento.valor, p);
        if (p->proximo != NULL) {
            putchar('>');
        }
        p = p->proximo;
    }
    printf("|| (Cauda)");
}

// Versao iterativa da busca pela maior chave
int i_maiorChave(const struct Lista* l) {
    if (underflow(l)) {
        return -1;  // chave invalida
    }
    struct Noh* p = l->cabeca;
    int maior = p->elemento.chave;
    while (p != NULL) {
        if (p->elemento.chave > maior) {
            maior = p->elemento.chave;
        }
        p = p->proximo;
    }
    return maior;
}

static int maiorChave(const struct Noh* p) {
    // CONDICAO TERMINAL: Se nao tenho proximo, retorno a minha chave como sendo
    // a maior (dessa "lista" que comeca em mim)
    if (p->proximo == NULL) {
        return p->elemento.chave;
    }
    else {
        // FASE ATIVA: chama recursivamente pra retornar a maior chave da
        // sequencia da lista (apos o noh em que eu estou)
        int seguinte = maiorChave(p->proximo);
        if (seguinte > p->elemento.chave) {
            return seguinte;
        }
        else {
            return p->elemento.chave;
        }
    }
}

// Versao recursiva da busca pela maior chave
int r_maiorChave(const struct Lista* l) {
    if (underflow(l)) {
        return -1;
    }
    // Como a struct Lista nao se repete pela estrutura, mas sim a struct Noh,
    // eh com base nessa struct (Noh) que devo fazer a funcao recursiva
    return maiorChave(l->cabeca);
}
