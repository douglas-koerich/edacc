#ifndef LISTA_H
#define LISTA_H

#include <stdbool.h>

// Definicao do registro armazenado na lista encadeada
struct Reg {
    int chave;  // Chave de busca
    int valor;  // Um exemplo de informacao associada a chave nesse registro
};
typedef struct Reg Reg;

// Definicao de um registro invalido
extern const Reg REG_INVALIDO;

// Definicao do TAD: Lista encadeada simples de registros do tipo Reg
struct Lista;

// Operacoes do TAD
struct Lista* cria(void);
void destroi(struct Lista* l);
bool underflow(const struct Lista* l);
void insere(struct Lista* l, const Reg* novo);
void imprime(struct Lista* l);

// A mesma operacao de busca pela maior chave da lista, em suas versoes
// iterativa (i_) e recursiva (r_)
int i_maiorChave(const struct Lista* l);
int r_maiorChave(const struct Lista* l);

#endif
