#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "lista.h"

int main(void) {
    srand((unsigned) time(0));
    
    // Cria uma lista encadeada vazia
    struct Lista* lista = cria();

    // Gera um conjunto de registros para serem armazenados na lista
    Reg r;
    do {
        r.chave = rand() % 50;
        r.valor = rand() % 10000;
        insere(lista, &r);
    } while (r.chave > 10);
    printf("Lista: "); imprime(lista); putchar('\n');

    // Determina qual foi a maior chave armazenada na lista
    int mc = i_maiorChave(lista);
    printf("A maior chave encontrada na lista eh %d.\n", mc);
    mc = r_maiorChave(lista);
    printf("Encontrei novamente a mesma chave: %d.\n", mc);

    // Encerra lista
    destroi(lista);

    return EXIT_SUCCESS;
}
